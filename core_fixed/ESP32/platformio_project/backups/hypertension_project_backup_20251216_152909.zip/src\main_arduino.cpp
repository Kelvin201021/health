```cpp
// Removed duplicate Arduino entry to avoid duplicate setup()/loop()
// Keep `main.cpp` as the single Arduino entry file.
// Placeholder removed duplicate of main.cpp
// Placeholder removed duplicate of main.cpp
void setup() { Serial.begin(115200); }
void loop() { delay(1000); }
